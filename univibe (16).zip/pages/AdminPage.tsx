import React from 'react';

// This is a placeholder page. The actual admin pages are in the /pages/admin/ directory.
const AdminPage: React.FC = () => {
    return null;
};

export default AdminPage;
