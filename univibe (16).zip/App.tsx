import React, { lazy, Suspense } from 'react';
import { HashRouter as Router, Route, Routes, Navigate, Outlet } from 'react-router-dom';
import ProtectedRoute from './components/ProtectedRoute';
import { useAuth } from './hooks/useAuth';
import Spinner from './components/Spinner';
import { AuthProvider } from './contexts/AuthContext';
import { PresenceProvider } from './contexts/PresenceContext';
import AdminLayout from './layouts/AdminLayout';

// Lazy load all page components
const HomePage = lazy(() => import('./pages/HomePage'));
const ProfilePage = lazy(() => import('./pages/ProfilePage'));
const DirectoryPage = lazy(() => import('./pages/DirectoryPage'));
const ChatPage = lazy(() => import('./pages/ChatPage'));
const ChatListPage = lazy(() => import('./pages/ChatListPage'));
const CommunityListPage = lazy(() => import('./pages/CommunityListPage'));
const CommunityPage = lazy(() => import('./pages/CommunityPage'));
const SuggestionsPage = lazy(() => import('./pages/SuggestionsPage'));
const CollegeHubPage = lazy(() => import('./pages/CollegeHubPage'));
const EventsListPage = lazy(() => import('./pages/EventsListPage'));
const EventPage = lazy(() => import('./pages/EventPage'));
const AboutPage = lazy(() => import('./pages/AboutPage'));
const LoginPage = lazy(() => import('./pages/LoginPage'));
const RegisterPage = lazy(() => import('./pages/RegisterPage'));
const LandingPage = lazy(() => import('./pages/LandingPage'));
const PostPage = lazy(() => import('./pages/PostPage'));
const ForgotPasswordPage = lazy(() => import('./pages/ForgotPasswordPage'));
const UpdatePasswordPage = lazy(() => import('./pages/UpdatePasswordPage'));
const FriendsListPage = lazy(() => import('./pages/FriendsListPage'));
const FeedbackPage = lazy(() => import('./pages/FeedbackPage'));

// Lazy load admin pages
const AdminDashboardPage = lazy(() => import('./pages/admin/AdminDashboardPage'));
const AdminVerificationPage = lazy(() => import('./pages/admin/AdminVerificationPage'));
const AdminUserManagementPage = lazy(() => import('./pages/admin/AdminUserManagementPage'));
const AdminCommunityManagementPage = lazy(() => import('./pages/admin/AdminCommunityManagementPage'));
const AdminPostManagementPage = lazy(() => import('./pages/admin/AdminPostManagementPage'));
const AdminCollegeManagementPage = lazy(() => import('./pages/admin/AdminCollegeManagementPage'));
const AdminReportsPage = lazy(() => import('./pages/admin/AdminReportsPage'));
const AdminTeamManagementPage = lazy(() => import('./pages/admin/AdminTeamManagementPage'));
const AdminFeedbackPage = lazy(() => import('./pages/admin/AdminFeedbackPage'));


const VerifiedRoute: React.FC = () => {
    const { profile } = useAuth();

    // This route is nested under ProtectedRoute, so we can assume `profile` is loaded.
    if (!profile?.is_verified) {
        // Redirect non-verified users to their profile page, where they can see the 'Get Verified' button.
        return <Navigate to={`/profile/${profile?.id}`} replace />;
    }

    return <Outlet />;
};

const AppContent = () => {
    const { session, loading } = useAuth();

    if (loading) {
        return (
            <div className="flex h-screen items-center justify-center bg-background">
                <Spinner size="lg" />
            </div>
        );
    }

    return (
        <Suspense fallback={<div className="flex h-screen items-center justify-center bg-background"><Spinner size="lg" /></div>}>
            <Routes>
                {session ? (
                    <>
                        <Route element={<ProtectedRoute />}>
                            {/* General Authenticated Routes */}
                            <Route path="/home" element={<HomePage />} />
                            <Route path="/post/:id" element={<PostPage />} />
                            <Route path="/profile/:id" element={<ProfilePage />} />
                            <Route path="/find-fellows" element={<DirectoryPage />} />
                            <Route path="/suggestions" element={<SuggestionsPage />} />
                            <Route path="/friends" element={<FriendsListPage />} />
                            <Route path="/feedback" element={<FeedbackPage />} />
                            <Route path="/communities" element={<CommunityListPage />} />
                            <Route path="/community/:id" element={<CommunityPage />} />
                            <Route path="/about" element={<AboutPage />} />
                            <Route path="/chat" element={<ChatListPage />} />
                            <Route path="/chat/:recipientId" element={<ChatPage />} />

                            {/* Routes requiring student verification */}
                            <Route element={<VerifiedRoute />}>
                                <Route path="/college-hub" element={<CollegeHubPage />} />
                                <Route path="/events" element={<EventsListPage />} />
                                <Route path="/event/:id" element={<EventPage />} />
                            </Route>
                        </Route>
                        
                        {/* Admin Routes with their own layout */}
                        <Route path="/admin" element={<AdminLayout />}>
                            <Route path="dashboard" element={<AdminDashboardPage />} />
                            <Route path="verification" element={<AdminVerificationPage />} />
                            <Route path="users" element={<AdminUserManagementPage />} />
                            <Route path="communities" element={<AdminCommunityManagementPage />} />
                            <Route path="posts" element={<AdminPostManagementPage />} />
                            <Route path="colleges" element={<AdminCollegeManagementPage />} />
                            <Route path="reports" element={<AdminReportsPage />} />
                            <Route path="feedback" element={<AdminFeedbackPage />} />
                            <Route path="team" element={<AdminTeamManagementPage />} />
                            <Route index element={<Navigate to="dashboard" replace />} />
                        </Route>

                        {/* If logged in, any other path redirects to home */}
                        <Route path="*" element={<Navigate to="/home" replace />} />
                    </>
                ) : (
                    <>
                        <Route path="/" element={<LandingPage />} />
                        <Route path="/login" element={<LoginPage />} />
                        <Route path="/register" element={<RegisterPage />} />
                        <Route path="/forgot-password" element={<ForgotPasswordPage />} />
                        <Route path="/update-password" element={<UpdatePasswordPage />} />
                        {/* If not logged in, any other path redirects to landing page */}
                        <Route path="*" element={<Navigate to="/" replace />} />
                    </>
                )}
            </Routes>
        </Suspense>
    );
};

const App: React.FC = () => {
    return (
        <AuthProvider>
            <PresenceProvider>
                <Router>
                    <AppContent />
                </Router>
            </PresenceProvider>
        </AuthProvider>
    );
};

export default App;
