import { definitions } from './supabase-types';

export interface Profile {
    id: string;
    name: string;
    username: string | null;
    avatar_url: string | null;
    college: string | null;
    state: string | null;
    bio: string | null;
    course: string | null;
    joining_year: number | null;
    hobbies_interests: string | null;
    enrollment_status: 'current_student' | 'incoming_student' | null;
    email: string;
    last_seen: string | null;
    is_verified: boolean;
    is_banned: boolean;
    profile_remark: string | null;
    created_at: string;
}

export interface Post {
    id: number;
    content: string;
    image_url: string | null;
    user_id: string;
    created_at: string;
    community_id: number | null;
}

export interface Like {
    id: number;
    user_id: string;
    post_id: number;
}

export interface Comment {
    id: number;
    content: string;
    user_id: string;
    post_id: number;
    created_at: string;
}

export interface Community {
    id: number;
    name: string;
    description: string | null;
    banner_url: string | null;
    creator_id: string;
    college: string | null;
    is_verified: boolean;
    created_at: string;
}

export interface Message {
    id: number;
    sender_id: string;
    receiver_id: string;
    content: string;
    created_at: string;
    is_seen: boolean;
    file_url?: string | null;
    file_type?: string | null;
}

export interface Follow {
    id: number;
    follower_id: string;
    following_id: string;
    created_at: string;
}

export interface Notification {
    id: number;
    user_id: string; // The user who receives the notification
    actor_id: string; // The user who performed the action
    type: 'new_follower' | 'new_comment' | 'new_like' | 'new_message' | 'verification_approved' | 'verification_rejected';
    entity_id: number; // e.g., follow id, post id, message id
    is_read: boolean;
    created_at: string;
}

export interface CommunityMember {
    community_id: number;
    user_id: string;
    created_at: string;
    can_post: boolean;
}

export interface CommunityFile {
    id: number;
    community_id: number;
    user_id: string;
    file_name: string;
    file_url: string;
    file_type: string;
    description: string | null;
    created_at: string;
}

export interface VerificationSubmission {
    id: number;
    user_id: string;
    id_card_url: string;
    status: 'pending' | 'approved' | 'rejected';
    created_at: string;
    reviewed_at: string | null;
    reviewer_notes: string | null;
    reviewer_id: string | null;
}

export interface College {
    id: number;
    name: string;
    created_at: string;
    accepted_domain: string | null;
}

export interface Event {
    id: number;
    name: string;
    description: string | null;
    banner_url: string | null;
    event_date: string;
    location: string | null;
    creator_id: string;
    college: string | null;
    created_at: string;
    rsvp_limit: number | null;
}

export interface EventAttendee {
    event_id: number;
    user_id: string;
    created_at: string;
}

export interface Complaint {
    id: number;
    created_at: string;
    user_id: string;
    college: string;
    category: string;
    title: string;
    description: string;
    status: 'submitted' | 'in_review' | 'resolved';
    admin_notes: string | null;
    resolved_at: string | null;
}

export interface CollegeGroupMessage {
    id: number;
    created_at: string;
    user_id: string;
    college: string;
    content: string;
}

export interface Report {
    id: number;
    created_at: string;
    reporter_id: string;
    entity_type: 'profile' | 'post' | 'comment' | 'message';
    entity_id: string;
    reason: string;
    status: 'pending' | 'reviewed' | 'resolved';
    notes: string | null;
}

export interface TeamMember {
    id: number;
    created_at: string;
    name: string;
    role: string;
    avatar_url: string | null;
    bio: string | null;
    linkedin_url: string | null;
    twitter_url: string | null;
    github_url: string | null;
}

export interface Feedback {
    id: number;
    created_at: string;
    user_id: string;
    category: 'Bug Report' | 'Feature Request' | 'General Feedback' | 'Other';
    title: string;
    description: string;
    status: 'submitted' | 'in_review' | 'resolved';
    admin_reply: string | null;
    replied_at: string | null;
    replied_by: string | null;
}


// Joined types
export interface PostWithProfile extends Post {
    profiles: Profile;
    likes: Like[];
    comments: { count: number }[];
}

export interface CommentWithProfile extends Comment {
    profiles: Profile;
}

export interface CommunityWithCreator extends Community {
    profiles: Profile;
}

export interface Conversation {
    profile: Profile;
    last_message: Message;
}

export interface NotificationWithActor extends Notification {
    profiles: Profile; // The actor's profile
}

export interface CommunityWithMemberCount extends Community {
    community_member_counts: { count: number }[];
}

export interface CommunityMemberWithProfile {
    user_id: string;
    created_at: string;
    can_post: boolean;
    profiles: Profile;
}

export interface CommunityFileWithUploader extends CommunityFile {
    profiles: Profile;
}

export interface VerificationSubmissionWithProfile extends VerificationSubmission {
    profiles: Profile;
    reviewer?: Pick<Profile, 'id' | 'name' | 'avatar_url'> | null;
}

export interface EventWithCreatorAndAttendees extends Event {
    profiles: Profile; // creator profile
    event_attendees: { user_id: string, profiles: Pick<Profile, 'id' | 'name' | 'avatar_url'> }[];
}

export interface ComplaintWithProfile extends Complaint {
    profiles: Profile;
}

export interface CollegeGroupMessageWithProfile extends CollegeGroupMessage {
    profiles: Profile;
}

export interface FeedbackWithUser extends Feedback {
    profiles: Profile;
}


// Supabase generated types (simplified for this context)
export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: Profile;
        Insert: Omit<Profile, 'id' | 'last_seen' | 'is_verified' | 'is_banned' | 'profile_remark'>;
        Update: Partial<Profile>;
      };
      posts: {
        Row: Post;
        Insert: Omit<Post, 'id' | 'created_at'>;
        Update: Partial<Omit<Post, 'id' | 'user_id' | 'created_at'>>;
      };
      likes: {
        Row: Like;
        Insert: Omit<Like, 'id'>;
      };
       comments: {
        Row: Comment;
        Insert: Omit<Comment, 'id' | 'created_at'>;
        Update: Partial<Comment>;
      };
      communities: {
        Row: Community;
        Insert: Omit<Community, 'id' | 'created_at' | 'is_verified'> & { creator_id: string };
      };
      messages: {
        Row: Message;
        Insert: Omit<Message, 'id' | 'created_at' | 'is_seen'>;
        Update: Partial<Message>;
      };
      follows: {
        Row: Follow;
        Insert: Omit<Follow, 'id' | 'created_at'>;
        Update: Partial<Follow>;
      };
      notifications: {
        Row: Notification;
        Insert: Omit<Notification, 'id' | 'created_at' | 'is_read'>;
        Update: Partial<Notification>;
      };
      community_members: {
        Row: CommunityMember;
        Insert: Omit<CommunityMember, 'created_at'>;
        Update: Partial<CommunityMember>;
      };
      community_files: {
        Row: CommunityFile;
        Insert: Omit<CommunityFile, 'id' | 'created_at'>;
      };
      verification_submissions: {
          Row: VerificationSubmission;
          Insert: Omit<VerificationSubmission, 'id' | 'created_at' | 'reviewed_at' | 'reviewer_notes' | 'status'>;
          Update: Partial<VerificationSubmission>;
      };
      colleges: {
        Row: College;
        Insert: Omit<College, 'id' | 'created_at'>;
        Update: Partial<College>;
      };
      events: {
          Row: Event;
          Insert: Omit<Event, 'id' | 'created_at'>;
          Update: Partial<Omit<Event, 'id' | 'creator_id' | 'created_at'>>;
      };
      event_attendees: {
          Row: EventAttendee;
          Insert: Omit<EventAttendee, 'created_at'>;
      };
      complaints: {
          Row: Complaint;
          Insert: Omit<Complaint, 'id' | 'created_at' | 'status' | 'admin_notes' | 'resolved_at'>;
          Update: Partial<Omit<Complaint, 'id' | 'user_id' | 'created_at'>>;
      };
      college_group_chats: {
        Row: CollegeGroupMessage;
        Insert: Omit<CollegeGroupMessage, 'id' | 'created_at'>;
        Update: Partial<CollegeGroupMessage>;
      };
      reports: {
        Row: Report;
        Insert: Omit<Report, 'id' | 'created_at' | 'status' | 'notes'>;
        Update: Partial<Report>;
      };
      team_members: {
        Row: TeamMember;
        Insert: Omit<TeamMember, 'id' | 'created_at'>;
        Update: Partial<Omit<TeamMember, 'id' | 'created_at'>>;
      };
      feedback: {
        Row: Feedback;
        Insert: Omit<Feedback, 'id' | 'created_at' | 'status' | 'admin_reply' | 'replied_at' | 'replied_by'>;
        Update: Partial<Feedback>;
      };
    };
    Views: {
      community_member_counts: {
        Row: {
          community_id: number | null
          count: number | null
        }
      },
      daily_stats: {
        Row: {
            date: string | null;
            total_users: number | null;
            posts_today: number | null;
            total_communities: number | null;
        }
      }
    }
    Functions: {
      create_community_and_add_creator: {
        Args: {
          community_name: string;
          community_description: string;
          banner_url: string;
          college: string;
        };
        Returns: number;
      };
      update_last_seen: {
        Args: Record<string, unknown>;
        Returns: void;
      };
      approve_verification: {
        Args: {
          p_submission_id: bigint;
        };
        Returns: void;
      };
      reject_verification: {
        Args: {
          p_submission_id: bigint;
          rejection_reason: string;
        };
        Returns: void;
      };
      admin_create_community: {
        Args: {
          community_name: string;
          community_description: string | null;
          banner_url: string | null;
          college: string;
          is_verified: boolean;
          creator_email: string;
        };
        Returns: number;
      };
      toggle_user_ban: {
        Args: {
            target_user_id: string;
        };
        Returns: void;
      };
      admin_delete_post: {
        Args: {
            post_id_to_delete: bigint;
        };
        Returns: void;
      };
      admin_delete_community: {
        Args: {
            community_id_to_delete: bigint;
        };
        Returns: void;
      };
      admin_set_user_remark: {
        Args: {
          target_user_id: string;
          remark_text: string | null;
        };
        Returns: void;
      };
       mark_all_notifications_as_read: {
        Args: Record<string, unknown>;
        Returns: void;
      };
      delete_post: {
        Args: {
          post_id_to_delete: bigint;
        };
        Returns: string;
      };
      toggle_like_and_notify: {
        Args: {
          p_post_id: bigint;
          p_post_owner_id: string;
        };
        Returns: void;
      };
      add_comment_and_notify: {
        Args: {
          p_post_id: bigint;
          p_content: string;
          p_post_owner_id: string;
        };
        Returns: void;
      };
      send_message_and_notify: {
        Args: {
          p_receiver_id: string;
          p_content: string;
          p_file_url: string | null;
          p_file_type: string | null;
        };
        Returns: definitions['messages'];
      };
    }
  }
}
