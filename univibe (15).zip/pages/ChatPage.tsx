import React, { useState, useEffect, useCallback, useRef } from 'react';
import { useParams, Link, useLocation } from 'react-router-dom';
import { supabase } from '../services/supabase';
import { useAuth } from '../hooks/useAuth';
import { Profile, Message } from '../types';
import Spinner from '../components/Spinner';
import { format, formatDistanceToNowStrict } from 'date-fns';
import { usePresence } from '../contexts/PresenceContext';
import { RealtimeChannel } from '@supabase/supabase-js';
import VerifiedBadge from '../components/VerifiedBadge';
import IcebreakerModal from '../components/IcebreakerModal';

const FileMessageContent: React.FC<{ message: Message }> = ({ message }) => {
    const [url, setUrl] = useState<string | null>(null);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        if (!message.file_url) {
            setLoading(false);
            return;
        }

        // Backwards compatibility for any old messages that might have a full public URL
        if (message.file_url.startsWith('http')) {
            setUrl(message.file_url);
            setLoading(false);
            return;
        }

        const createSignedUrl = async () => {
            // It's a path, create a temporary signed URL
            const { data, error } = await supabase.storage
                .from('chat-files')
                .createSignedUrl(message.file_url!, 60 * 5); // URL valid for 5 minutes

            if (error) {
                console.error('Error creating signed URL:', error);
                setUrl(null);
            } else {
                setUrl(data.signedUrl);
            }
            setLoading(false);
        };

        createSignedUrl();
    }, [message.file_url]);


    if (!message.file_url || !message.file_type) return null;

    if (loading) {
        return <div className="mt-2 flex justify-center items-center h-24 w-24 bg-slate-100 rounded-lg"><Spinner size="sm" /></div>;
    }

    if (!url) {
        return <div className="mt-2 text-red-600 text-xs p-2 bg-red-100 rounded-lg">Could not load file.</div>;
    }

    if (message.file_type.startsWith('image/')) {
        return <img src={url} alt="Shared content" className="mt-2 rounded-lg max-w-full h-auto max-h-64 object-contain" />;
    }

    // Generic file link
    const fileName = message.file_url.split('/').pop()?.split('_').slice(1).join('_') || 'Download File';
    return (
        <a href={url} target="_blank" rel="noopener noreferrer" download={fileName} className="mt-2 flex items-center gap-2 bg-slate-300/50 p-2 rounded-lg hover:bg-slate-300/80 transition-colors">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6 flex-shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
            <span className="truncate text-sm">{fileName}</span>
        </a>
    );
};


const ChatMessage: React.FC<{ message: Message; isSender: boolean }> = ({ message, isSender }) => {
    const messageClasses = isSender
        ? 'bg-primary text-white self-end rounded-t-xl rounded-bl-xl'
        : 'bg-slate-200 text-text-heading self-start rounded-t-xl rounded-br-xl';
    
    return (
        <div className={`flex flex-col ${isSender ? 'items-end' : 'items-start'}`}>
            <div className={`max-w-xs md:max-w-md p-3 shadow-sm ${messageClasses}`}>
                {message.content && <p className="whitespace-pre-wrap">{message.content}</p>}
                <FileMessageContent message={message} />
            </div>
             <p className={`text-xs text-text-muted mt-1 px-1`}>
                {format(new Date(message.created_at), 'p')}
            </p>
        </div>
    );
};


const ChatPage: React.FC = () => {
    const { recipientId } = useParams<{ recipientId: string }>();
    const { user, profile: currentUserProfile } = useAuth();
    const location = useLocation();
    const prefilledMessage = location.state?.prefilledMessage;

    const [recipientProfile, setRecipientProfile] = useState<Profile | null>(null);
    const [messages, setMessages] = useState<Message[]>([]);
    const [newMessage, setNewMessage] = useState(prefilledMessage || '');
    const [fileToSend, setFileToSend] = useState<File | null>(null);
    const [filePreview, setFilePreview] = useState<string | null>(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState<string | null>(null);
    const [isSending, setIsSending] = useState(false);
    const [isIcebreakerModalOpen, setIsIcebreakerModalOpen] = useState(false);
    const [isRecipientTyping, setIsRecipientTyping] = useState(false);
    
    const messagesEndRef = useRef<HTMLDivElement | null>(null);
    const fileInputRef = useRef<HTMLInputElement | null>(null);
    const typingTimeoutRef = useRef<ReturnType<typeof setTimeout> | null>(null);
    const typingChannelRef = useRef<RealtimeChannel | null>(null);
    
    const { onlineUsers } = usePresence();
    const isRecipientOnline = recipientId ? onlineUsers.has(recipientId) : false;

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    };

    // Clear location state after using it
    useEffect(() => {
        if (prefilledMessage) {
            // Replace the current entry in the history stack
            window.history.replaceState({}, document.title);
        }
    }, [prefilledMessage]);

    useEffect(() => {
        scrollToBottom();
    }, [messages, isRecipientTyping]);
    
    const resetFileInput = () => {
        setFileToSend(null);
        setFilePreview(null);
        if(fileInputRef.current) fileInputRef.current.value = "";
    };

    const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        if (e.target.files && e.target.files[0]) {
            const file = e.target.files[0];
            if(file.size > 10 * 1024 * 1024) { // 10MB limit
                alert("File is too large. Max size is 10MB.");
                resetFileInput();
                return;
            }
            setFileToSend(file);
            if (file.type.startsWith('image/')) {
                setFilePreview(URL.createObjectURL(file));
            } else {
                setFilePreview(file.name); // Show filename for non-images
            }
        }
    };

    const markMessagesAsSeen = useCallback(async () => {
        if (!user || !recipientId || document.hidden) return;
        
        const { error } = await supabase
            .from('messages')
            .update({ is_seen: true })
            .eq('receiver_id', user.id)
            .eq('sender_id', recipientId)
            .eq('is_seen', false);

        if (error) {
            console.error('Error marking messages as seen:', error);
        }
    }, [user, recipientId]);

    const fetchChatData = useCallback(async () => {
        if (!recipientId || !user) return;
        setLoading(true);
        setError(null);
        
        try {
            const { data: recipientData, error: recipientError } = await supabase
                .from('profiles')
                .select('*')
                .eq('id', recipientId)
                .single();
            if (recipientError) throw recipientError;
            setRecipientProfile(recipientData);

            const { data: messagesData, error: messagesError } = await supabase
                .from('messages')
                .select('*')
                .or(`and(sender_id.eq.${user.id},receiver_id.eq.${recipientId}),and(sender_id.eq.${recipientId},receiver_id.eq.${user.id})`)
                .order('created_at', { ascending: true });

            if (messagesError) throw messagesError;
            setMessages(messagesData as Message[]);
            
        } catch (e: any) {
             setError(e.message.includes('0 rows') ? "User not found." : e.message);
        } finally {
            setLoading(false);
        }
    }, [recipientId, user]);
    
    useEffect(() => {
        fetchChatData();
    }, [fetchChatData]);
    
    useEffect(() => {
        markMessagesAsSeen();
        
        const handleVisibilityChange = () => {
            if (!document.hidden) {
                markMessagesAsSeen();
            }
        };

        document.addEventListener('visibilitychange', handleVisibilityChange);
        return () => document.removeEventListener('visibilitychange', handleVisibilityChange);
    }, [messages, markMessagesAsSeen]);

    useEffect(() => {
        if (!user || !recipientId) return;
        
        // Channel for messages
        const messageChannelName = [user.id, recipientId].sort().join('-');
        const messageChannel = supabase
            .channel(`messages-chat-${messageChannelName}`)
            .on(
                'postgres_changes',
                { 
                    event: '*', 
                    schema: 'public', 
                    table: 'messages',
                    filter: `or=(and(sender_id.eq.${user.id},receiver_id.eq.${recipientId}),and(sender_id.eq.${recipientId},receiver_id.eq.${user.id}))`
                },
                (payload) => {
                    if (payload.eventType === 'INSERT') {
                        const newMessage = payload.new as Message;
                        setMessages(currentMessages => {
                            if (currentMessages.some(m => m.id === newMessage.id)) {
                                return currentMessages;
                            }
                            // If the new message is from the other user, mark as seen
                            if(newMessage.sender_id === recipientId) {
                                markMessagesAsSeen();
                            }
                            return [...currentMessages, newMessage];
                        });
                    } else if (payload.eventType === 'UPDATE') {
                        setMessages(currentMessages => 
                            currentMessages.map(m => m.id === (payload.new as Message).id ? (payload.new as Message) : m)
                        );
                    }
                }
            )
            .subscribe();
        
        // Channel for typing indicators
        const typingChannelName = `typing-${[user.id, recipientId].sort().join('-')}`;
        const typingChannel = supabase.channel(typingChannelName, {
            config: { presence: { key: user.id } }
        });
        typingChannelRef.current = typingChannel;

        typingChannel.on('presence', { event: 'sync' }, () => {
            const presenceState = typingChannel.presenceState();
            const recipientPresence = presenceState[recipientId];
            if (recipientPresence && (recipientPresence[0] as any)?.is_typing) {
                setIsRecipientTyping(true);
            } else {
                setIsRecipientTyping(false);
            }
        });
        
        typingChannel.subscribe(async (status) => {
            if (status === 'SUBSCRIBED') {
                await typingChannel.track({ is_typing: false });
            }
        });

        return () => {
            supabase.removeChannel(messageChannel);
            supabase.removeChannel(typingChannel);
            typingChannelRef.current = null;
        };
    }, [recipientId, user, markMessagesAsSeen]);
    
    const handleTyping = (isTyping: boolean) => {
        if (typingChannelRef.current) {
            typingChannelRef.current.track({ is_typing: isTyping });
        }
    };
    
    const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        setNewMessage(e.target.value);
        if (!typingTimeoutRef.current) {
            handleTyping(true);
        }
        if (typingTimeoutRef.current) {
            clearTimeout(typingTimeoutRef.current);
        }
        typingTimeoutRef.current = setTimeout(() => {
            handleTyping(false);
            typingTimeoutRef.current = null;
        }, 2000);
    };

    const handleSendMessage = async (e: React.FormEvent) => {
        e.preventDefault();
        if ((!newMessage.trim() && !fileToSend) || !user || !recipientId) return;

        setIsSending(true);
        handleTyping(false);
        if (typingTimeoutRef.current) {
            clearTimeout(typingTimeoutRef.current);
            typingTimeoutRef.current = null;
        }
        
        try {
            let fileUrl: string | null = null;
            let fileType: string | null = null;

            if (fileToSend) {
                const filePath = `${user.id}/${recipientId}/${Date.now()}_${fileToSend.name}`;
                const { data: uploadData, error: uploadError } = await supabase.storage
                    .from('chat-files')
                    .upload(filePath, fileToSend);
                
                if (uploadError) {
                    console.error("Storage Upload Error:", uploadError);
                    throw new Error(`Failed to upload file. ${uploadError.message}`);
                };
                if (!uploadData?.path) {
                    throw new Error("File upload failed: path not returned from storage.");
                }
                
                fileUrl = uploadData.path;
                fileType = fileToSend.type;
            }
            
            // Using the RPC function for an atomic operation
            const { data: newMessageData, error: rpcError } = await supabase.rpc('send_message_and_notify', {
                p_receiver_id: recipientId,
                p_content: newMessage.trim(),
                p_file_url: fileUrl,
                p_file_type: fileType,
            });

            if (rpcError) {
                throw rpcError;
            }

            // The RPC call was successful.
            // Add the new message to the sender's UI immediately.
            // The realtime listener on the other end should pick up the change,
            // and the duplicate check in our own listener will prevent double-adding.
            if (newMessageData) {
                setMessages(current => [...current, newMessageData]);
            }
            
            setNewMessage('');
            resetFileInput();

        } catch (err: any) {
            console.error('Error sending message:', err);
            alert(`Failed to send message: ${err.message}`);
        } finally {
            setIsSending(false);
        }
    };

    const handleSelectIcebreaker = (question: string) => {
        setNewMessage(question);
        setIsIcebreakerModalOpen(false);
    };


    if (loading) {
        return <div className="flex h-[calc(100vh-128px)] items-center justify-center"><Spinner size="lg" /></div>;
    }

    if (error) {
        return <p className="text-center text-red-500 p-8">{error}</p>;
    }

    if (!recipientProfile) {
        return <p className="text-center text-gray-500 p-8">Could not load user profile.</p>;
    }

    const lastMessage = messages.length > 0 ? messages[messages.length - 1] : null;
    const isLastMessageSeen = lastMessage && lastMessage.sender_id === user?.id && lastMessage.is_seen;
    
    const getStatusText = () => {
        if (isRecipientTyping) return 'typing...';
        if (isRecipientOnline) return 'Online';
        if (recipientProfile.last_seen) {
            return `Last seen ${formatDistanceToNowStrict(new Date(recipientProfile.last_seen))} ago`;
        }
        return 'Offline';
    }

    return (
        <div className="flex flex-col h-[calc(100vh-128px)] max-w-3xl mx-auto bg-card rounded-2xl shadow-soft border border-slate-200/50">
            <header className="p-4 border-b border-slate-200 flex items-center gap-3">
                <Link to="/chat" className="p-2 -ml-2 text-text-muted hover:text-primary rounded-full transition-colors" aria-label="Back to messages">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                        <path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" />
                    </svg>
                </Link>
                <Link to={`/profile/${recipientProfile.id}`}>
                    <img 
                        src={recipientProfile.avatar_url || `https://avatar.vercel.sh/${recipientProfile.id}.png`}
                        alt={recipientProfile.name}
                        className="w-10 h-10 rounded-full object-cover"
                    />
                </Link>
                <div>
                     <div className="flex items-center gap-2">
                        <Link to={`/profile/${recipientProfile.id}`} className="font-bold text-text-heading hover:underline">{recipientProfile.name}</Link>
                        {recipientProfile.is_verified && <VerifiedBadge />}
                        <div className={`h-2.5 w-2.5 rounded-full transition-colors ${isRecipientOnline ? 'bg-green-500' : 'bg-slate-400'}`}></div>
                     </div>
                     <p className="text-xs text-text-muted h-4">{getStatusText()}</p>
                </div>
            </header>

            <main className="flex-1 p-4 overflow-y-auto space-y-4">
                {messages.map(msg => (
                    <ChatMessage key={msg.id} message={msg} isSender={msg.sender_id === user?.id} />
                ))}
                {isRecipientTyping && (
                    <div className="flex items-start gap-2 animate-fade-in-up" style={{ animationDuration: '0.3s' }}>
                        <div className="bg-slate-200 text-text-heading self-start rounded-t-xl rounded-br-xl p-3">
                            <div className="flex items-center gap-1.5">
                                <span className="h-2 w-2 bg-slate-400 rounded-full animate-bounce [animation-delay:-0.3s]"></span>
                                <span className="h-2 w-2 bg-slate-400 rounded-full animate-bounce [animation-delay:-0.15s]"></span>
                                <span className="h-2 w-2 bg-slate-400 rounded-full animate-bounce"></span>
                            </div>
                        </div>
                    </div>
                )}
                {isLastMessageSeen && (
                    <p className="text-right text-xs text-text-muted pr-1">Seen</p>
                )}
                <div ref={messagesEndRef} />
            </main>

            <footer className="p-4 border-t border-slate-200 space-y-2">
                 {fileToSend && (
                    <div className="p-2 bg-slate-100 rounded-lg flex items-center justify-between">
                        {filePreview && fileToSend.type.startsWith('image/') ? (
                            <img src={filePreview} alt="Preview" className="w-12 h-12 object-cover rounded-md" />
                        ) : (
                             <div className="flex items-center gap-2 text-sm text-text-body">
                                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" /></svg>
                                <span className="truncate max-w-xs">{filePreview}</span>
                            </div>
                        )}
                        <button onClick={resetFileInput} className="p-1.5 rounded-full hover:bg-slate-200 transition-colors">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
                        </button>
                    </div>
                )}
                <form onSubmit={handleSendMessage} className="flex items-center gap-2 relative">
                     <button type="button" onClick={() => fileInputRef.current?.click()} className="text-text-muted hover:text-primary transition-colors p-3 rounded-lg flex-shrink-0">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15.172 7l-6.586 6.586a2 2 0 102.828 2.828l6.414-6.586a4 4 0 00-5.656-5.656l-6.415 6.585a6 6 0 108.486 8.486L20.5 13" /></svg>
                        <input type="file" ref={fileInputRef} onChange={handleFileChange} className="hidden" />
                    </button>
                    <input 
                        type="text"
                        value={newMessage}
                        onChange={handleInputChange}
                        placeholder="Type a message..."
                        className="w-full p-3 pr-24 bg-slate-100 border-2 border-transparent rounded-lg focus:outline-none focus:ring-2 focus:ring-primary/50 focus:border-primary text-text-heading placeholder:text-text-muted transition-colors"
                        disabled={isSending}
                    />
                     <button type="button" onClick={() => setIsIcebreakerModalOpen(true)} className="absolute right-20 top-1/2 -translate-y-1/2 text-text-muted hover:text-secondary transition-colors p-2 rounded-full" title="Generate AI Icebreaker">
                        <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                            <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                        </svg>
                    </button>
                     <button type="submit" disabled={isSending || (!newMessage.trim() && !fileToSend)} className="text-white bg-primary disabled:bg-slate-400 hover:bg-primary-focus transition-colors rounded-lg p-3 flex-shrink-0">
                         {isSending ? <Spinner size="sm" /> : <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 20 20" fill="currentColor"><path d="M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5-1.429A1 1 0 009 15.571V11a1 1 0 112 0v4.571a1 1 0 00.725.962l5 1.428a1 1 0 001.17-1.408l-7-14z" /></svg>}
                    </button>
                </form>
            </footer>
            {isIcebreakerModalOpen && currentUserProfile && recipientProfile && (
                <IcebreakerModal
                    currentUser={currentUserProfile}
                    targetUser={recipientProfile}
                    onClose={() => setIsIcebreakerModalOpen(false)}
                    onSelectQuestion={handleSelectIcebreaker}
                />
            )}
        </div>
    );
};

export default ChatPage;