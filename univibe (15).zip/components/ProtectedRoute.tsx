
import React from 'react';
import { Navigate, Outlet, useLocation } from 'react-router-dom';
import { useAuth } from '../hooks/useAuth';
import Navbar from './Navbar';
import Spinner from './Spinner';

const ProtectedRoute: React.FC = () => {
    const { session, profile, user, loading } = useAuth();
    const location = useLocation();

    if (loading) {
        return (
            <div className="flex h-screen items-center justify-center bg-background">
                <Spinner size="lg" />
            </div>
        );
    }

    if (!session || !user) {
        return <Navigate to="/login" replace />;
    }

    // If profile is loaded, check if it's complete.
    // An incomplete profile is one without a college (for 'exploring' users).
    // We allow access to their own profile page, about, and feedback.
    const isProfileIncomplete = profile && !profile.college;
    const allowedPaths = [`/profile/${user.id}`, '/about', '/feedback'];
    const isAllowedPath = allowedPaths.includes(location.pathname);

    if (isProfileIncomplete && !isAllowedPath) {
        // Redirect to their own profile page if it's incomplete and they are trying to access other pages.
        return <Navigate to={`/profile/${user.id}`} replace />;
    }


    return (
        <div className="min-h-screen bg-background text-text-body md:flex">
            <Navbar />
            <main className="flex-1 md:ml-64">
                <div className="container mx-auto max-w-7xl px-4 py-8 sm:px-6 lg:px-8">
                     <Outlet />
                </div>
            </main>
        </div>
    );
};

export default ProtectedRoute;