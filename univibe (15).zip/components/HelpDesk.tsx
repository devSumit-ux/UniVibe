import React, { useState, useEffect, useCallback } from 'react';
import { supabase } from '../services/supabase';
import { useAuth } from '../hooks/useAuth';
import { Complaint } from '../types';
import Spinner from './Spinner';
import { format } from 'date-fns';

interface HelpDeskProps {
    collegeName: string;
}

const complaintCategories = ['Academics', 'Hostel', 'Campus Facilities', 'Faculty', 'Other'];

const ComplaintStatusBadge: React.FC<{ status: Complaint['status'] }> = ({ status }) => {
    const styles = {
        submitted: 'bg-blue-100 text-blue-800',
        in_review: 'bg-yellow-100 text-yellow-800',
        resolved: 'bg-green-100 text-green-800',
    };
    const text = {
        submitted: 'Submitted',
        in_review: 'In Review',
        resolved: 'Resolved',
    }
    return <span className={`px-2 py-0.5 text-xs font-semibold rounded-full ${styles[status]}`}>{text[status]}</span>;
};

const HelpDesk: React.FC<HelpDeskProps> = ({ collegeName }) => {
    const { user } = useAuth();
    const [title, setTitle] = useState('');
    const [description, setDescription] = useState('');
    const [category, setCategory] = useState(complaintCategories[0]);
    const [submitting, setSubmitting] = useState(false);
    const [error, setError] = useState<string | null>(null);
    const [success, setSuccess] = useState(false);
    
    const [myComplaints, setMyComplaints] = useState<Complaint[]>([]);
    const [loading, setLoading] = useState(true);

    const fetchComplaints = useCallback(async () => {
        if (!user) return;
        setLoading(true);
        const { data, error } = await supabase
            .from('complaints')
            .select('*')
            .eq('user_id', user.id)
            .order('created_at', { ascending: false });
        
        if (data) setMyComplaints(data);
        setLoading(false);
    }, [user]);

    useEffect(() => {
        fetchComplaints();
    }, [fetchComplaints]);
    
    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!user || !title.trim() || !description.trim()) return;

        setSubmitting(true);
        setError(null);
        setSuccess(false);

        const { error: insertError } = await supabase.from('complaints').insert({
            user_id: user.id,
            college: collegeName,
            category,
            title,
            description,
        });

        if (insertError) {
            setError(insertError.message);
        } else {
            setSuccess(true);
            setTitle('');
            setDescription('');
            setCategory(complaintCategories[0]);
            fetchComplaints(); // Refresh the list
            setTimeout(() => setSuccess(false), 3000);
        }
        setSubmitting(false);
    };

    const inputClasses = "w-full px-3 py-2 bg-slate-100 border border-slate-200 rounded-md focus:outline-none focus:ring-2 focus:ring-primary/50 text-sm";

    return (
        <div className="p-2 space-y-6">
            <div>
                <h3 className="text-xl font-bold text-text-heading">Raise an Issue</h3>
                <p className="text-sm text-text-muted mt-1">Submit a complaint or provide feedback. This will be reviewed by administrators.</p>
                <form onSubmit={handleSubmit} className="mt-4 space-y-4 p-4 bg-slate-50 rounded-lg">
                    {success && <p className="text-green-600 font-semibold text-sm">Your submission has been received!</p>}
                    <div>
                        <label className="block text-sm font-medium text-text-body mb-1">Category</label>
                        <select value={category} onChange={(e) => setCategory(e.target.value)} className={inputClasses}>
                            {complaintCategories.map(c => <option key={c} value={c}>{c}</option>)}
                        </select>
                    </div>
                     <div>
                        <label className="block text-sm font-medium text-text-body mb-1">Subject</label>
                        <input type="text" value={title} onChange={(e) => setTitle(e.target.value)} className={inputClasses} required />
                    </div>
                    <div>
                        <label className="block text-sm font-medium text-text-body mb-1">Details</label>
                        <textarea value={description} onChange={(e) => setDescription(e.target.value)} className={inputClasses} rows={4} required></textarea>
                    </div>
                    {error && <p className="text-red-500 text-sm">{error}</p>}
                    <div className="text-right">
                        <button type="submit" disabled={submitting} className="bg-primary text-white px-6 py-2 rounded-lg hover:bg-primary-focus transition-colors disabled:bg-slate-400 flex items-center justify-center min-w-[120px] font-semibold text-sm ml-auto">
                            {submitting ? <Spinner size="sm" /> : 'Submit'}
                        </button>
                    </div>
                </form>
            </div>
            <div>
                 <h3 className="text-xl font-bold text-text-heading">My Submissions</h3>
                 <div className="mt-4 space-y-3">
                    {loading ? <Spinner /> : myComplaints.length === 0 ? (
                        <p className="text-center text-text-muted text-sm py-4">You haven't submitted any issues yet.</p>
                    ) : (
                        myComplaints.map(c => (
                            <div key={c.id} className="bg-slate-50 p-3 rounded-lg">
                                <div className="flex justify-between items-start">
                                    <p className="font-semibold text-text-heading">{c.title}</p>
                                    <ComplaintStatusBadge status={c.status} />
                                </div>
                                <p className="text-xs text-text-muted mt-1">{c.category} &bull; {format(new Date(c.created_at), 'PP')}</p>
                                <p className="text-sm text-text-body mt-2">{c.description}</p>
                            </div>
                        ))
                    )}
                 </div>
            </div>
        </div>
    );
};

export default HelpDesk;
