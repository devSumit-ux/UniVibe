import React from 'react';

// This is a placeholder component. The MagicCard component is used for interactive cards instead.
const InteractiveCard: React.FC = () => {
    return null;
};

export default InteractiveCard;
